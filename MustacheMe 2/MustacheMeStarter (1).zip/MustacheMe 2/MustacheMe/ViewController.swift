//
//  ViewController.swift
//  MustacheMe
//
//  Created by  on 4/1/16.
//  Copyright © 2016 DocsApps. All rights reserved.
//

import UIKit

// add UIImagePickerControllerDelegate and UINavigationControllerDelegate for imagePicker

class ViewController: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate {

    @IBOutlet weak var myImageView: UIImageView!
    
    // create global variable for UIImagePicker
    let picker = UIImagePickerController()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // set imagePickers delegate to self
        picker.delegate = self
    }
    
    // load imagePickerController
    @IBAction func loadImage(_ sender: UIBarButtonItem) {
        let sheet = UIAlertController(title: "Select where to get image from", message: nil, preferredStyle: UIAlertControllerStyle.alert)
        let libraryAction = UIAlertAction(title: "PHOTO LIBRARY", style: UIAlertActionStyle.default) { (action) -> Void in
            self.picker.sourceType = UIImagePickerControllerSourceType.photoLibrary
            self.picker.delegate = self
            self.picker.modalPresentationStyle = .popover
            
            self.present(self.picker, animated: true, completion: nil)
        }
        let cameraAction = UIAlertAction(title: "CAMERA", style: UIAlertActionStyle.default) { (action) -> Void in
            if UIImagePickerController.availableCaptureModes(for: .rear) != nil
            {
                self.picker.sourceType = UIImagePickerControllerSourceType.camera
                self.picker.allowsEditing = true
                self.picker.cameraCaptureMode = .photo
                self.picker.modalPresentationStyle = .fullScreen
                self.picker.delegate = self
                
                self.present(self.picker, animated: true, completion: nil)
            }
            else{
                self.noCamera()
            }
        }
        let cancelAction = UIAlertAction(title: "CANCEL", style: .cancel)
        {(action) -> Void in
            self.dismiss(animated: true, completion: nil)
        }
        sheet.addAction(libraryAction)
        sheet.addAction(cameraAction)
        sheet.addAction(cancelAction)
        self.present(sheet, animated: true, completion: nil)
    }
    
    // dsiplays alert if device does not have a camera
    func noCamera(){
        let alertVC = UIAlertController(
            title: "No Camera",
            message: "Sorry, this device has no camera",
            preferredStyle: .alert)
        let okAction = UIAlertAction(
            title: "OK",
            style:.default,
            handler: nil)
        alertVC.addAction(okAction)
        present(
            alertVC,
            animated: true,
            completion: nil)
    }

    // MARK: - UIImagePickerControllerDelegate Methods
    
    // Dismiss imagePicker if user hits cancel
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        self.picker.dismiss(animated: true, completion: nil)
    }
    
    // add Method to set image
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        
        if picker.sourceType == .camera
        {
            // get the image the user selected
            if let pickedImage = info[UIImagePickerControllerEditedImage] as? UIImage
            {
                // set imageview's image and make aspect fit
                myImageView.contentMode = .scaleAspectFit
                myImageView.image = pickedImage
            }
        }
        else
        {
            // get the image the user selected
            if let pickedImage = info[UIImagePickerControllerOriginalImage] as? UIImage
            {
                // set imageview's image and make aspect fit
                myImageView.contentMode = .scaleAspectFit
                myImageView.image = pickedImage
            }
        }
        // dismiss imagePickerController
        dismiss(animated: true, completion: nil)
    }

    
    
    @IBAction func clearButton(_ sender: UIBarButtonItem) {
        
    }
}




